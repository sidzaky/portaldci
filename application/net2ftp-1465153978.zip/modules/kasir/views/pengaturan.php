<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Pengaturan <small></small>
                </h1>
            </div>
        </div>

        <!-- /.row -->

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">      
                  <div class="panel-heading"><i class="fa fa-fw fa-user"></i> Akun</div>
                  <div class="panel-body">
                    
                  </div>
                </div>
            </div>
        </div>

        <!-- /.row -->
        <br/>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">      
                  <div class="panel-heading">Hak Akses</div>
                  <div class="panel-body">
                        
                  </div>
                </div>
            </div>
        </div>

    </div>
</div>