<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Statistik <small></small>
                </h1>
            </div>
        </div>

        <!-- /.row -->

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">      
                  <div class="panel-heading">Panel heading without title</div>
                  <div class="panel-body">
                    <div id="spline" style="height: 300px;margin: 0px auto;">
                
                    </div>
                  </div>
                </div>
            </div>
        </div>

        <!-- /.row -->
        <br/>
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-default">      
                  <div class="panel-heading">Panel heading without title</div>
                  <div class="panel-body">
                        <div id="column" style="height: 300px;">
                            
                        </div>
                  </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-default">      
                  <div class="panel-heading">Panel heading without title</div>
                  <div class="panel-body">
                        <div id="pie" style="height: 300px;">
                            
                        </div>
                  </div>
                </div>
            </div>
        </div>

    </div>
</div>